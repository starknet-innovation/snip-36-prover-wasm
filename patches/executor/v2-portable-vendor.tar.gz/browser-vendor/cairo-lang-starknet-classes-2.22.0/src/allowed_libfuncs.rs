#![expect(clippy::disallowed_types)]

use std::collections::{HashMap, HashSet};
use std::fmt::{Display, Formatter};
use std::fs;

use cairo_lang_sierra::ids::GenericLibfuncId;
use serde::Deserialize;
use smol_str::SmolStr;
use thiserror::Error;

use crate::compiler_version::VersionId;

#[cfg(test)]
#[path = "allowed_libfuncs_test.rs"]
mod test;

#[derive(Error, Debug, Eq, PartialEq)]
pub enum AllowedLibfuncsError {
    #[error("Invalid Sierra program.")]
    SierraProgramError,
    #[error("No libfunc list named '{allowed_libfuncs_list_name}' is known.")]
    UnexpectedAllowedLibfuncsList { allowed_libfuncs_list_name: String },
    #[error("The allowed libfuncs file '{allowed_libfuncs_list_file}' was not found.")]
    UnknownAllowedLibfuncsFile { allowed_libfuncs_list_file: String },
    #[error("Failed to deserialize the allowed libfuncs file '{allowed_libfuncs_list_file}'.")]
    DeserializationError { allowed_libfuncs_list_file: String },
    #[error(
        "Libfunc {invalid_libfunc} is not allowed in the libfuncs list \
         '{allowed_libfuncs_list_name}'.\n Run with '--allowed-libfuncs-list-name \
         {BUILTIN_ALL_LIBFUNCS_LIST}' to allow all libfuncs."
    )]
    UnsupportedLibfunc { invalid_libfunc: String, allowed_libfuncs_list_name: String },
    #[error(
        "Libfunc {invalid_libfunc} requires version {required_version} while class version is {class_version}.\n
         Run with '--allowed-libfuncs-list-name {BUILTIN_ALL_LIBFUNCS_LIST}' to allow all libfuncs."
    )]
    UnsupportedLibfuncAtVersion {
        invalid_libfunc: String,
        required_version: VersionId,
        class_version: VersionId,
    },
    #[error(
        "Libfunc {invalid_libfunc} is deprecated since version {deprecated_version} while class \
         version is {class_version}.\n Run with '--allowed-libfuncs-list-name \
         {BUILTIN_ALL_LIBFUNCS_LIST}' to allow all libfuncs."
    )]
    DeprecatedLibfuncAtVersion {
        invalid_libfunc: String,
        deprecated_version: VersionId,
        class_version: VersionId,
    },
}

/// A selector for the allowed libfunc list.
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub enum ListSelector {
    /// A list with one of the predefined names.
    ListName(String),
    /// A list to be read from a file.
    ListFile(String),
    #[default]
    DefaultList,
}

impl ListSelector {
    /// Gets the CLI arguments of both the list name and list file and returns a
    /// selector, or None if both were supplied.
    pub fn new(list_name: Option<String>, list_file: Option<String>) -> Option<Self> {
        match (list_name, list_file) {
            // Both options supplied, can't decide.
            (Some(_), Some(_)) => None,
            (Some(list_name), None) => Some(Self::ListName(list_name)),
            (None, Some(list_file)) => Some(Self::ListFile(list_file)),
            (None, None) => Some(Self::default()),
        }
    }
}

impl Display for ListSelector {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        match self {
            ListSelector::ListName(s) => write!(f, "{s}"),
            ListSelector::ListFile(s) => write!(f, "{s}"),
            ListSelector::DefaultList => write!(f, "Default libfunc list"),
        }
    }
}

/// The Sierra version range in which a libfunc is allowed.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct AllowedVersions {
    /// The first Sierra version the libfunc is stable in; `None` for all versions.
    pub stable: Option<VersionId>,
    /// The first Sierra version the libfunc is deprecated in; `None` if not deprecated.
    pub deprecated: Option<VersionId>,
}
impl AllowedVersions {
    /// Validates that the libfunc is allowed in a class of the given Sierra version.
    pub fn validate(
        &self,
        libfunc: &GenericLibfuncId,
        class_version: VersionId,
    ) -> Result<(), AllowedLibfuncsError> {
        if let Some(required_version) = self.stable
            && !class_version.supports(required_version)
        {
            return Err(AllowedLibfuncsError::UnsupportedLibfuncAtVersion {
                invalid_libfunc: libfunc.to_string(),
                required_version,
                class_version,
            });
        }
        if let Some(deprecated_version) = self.deprecated
            && class_version.supports(deprecated_version)
        {
            return Err(AllowedLibfuncsError::DeprecatedLibfuncAtVersion {
                invalid_libfunc: libfunc.to_string(),
                deprecated_version,
                class_version,
            });
        }
        Ok(())
    }
}

/// Represents a list of allowed Sierra libfuncs.
#[derive(Debug, PartialEq, Eq, Deserialize)]
pub struct AllowedLibfuncs {
    #[serde(deserialize_with = "deserialize_libfuncs_map::<_>")]
    pub allowed_libfuncs: HashMap<GenericLibfuncId, AllowedVersions>,
}

/// Deserializes a map of allowed libfuncs from a file.
fn deserialize_libfuncs_map<'de, D: serde::Deserializer<'de>>(
    deserializer: D,
) -> Result<HashMap<GenericLibfuncId, AllowedVersions>, D::Error> {
    /// The representations of a single libfunc entry.
    #[derive(Deserialize)]
    #[serde(untagged)]
    enum EntryRepr {
        /// `null` or the legacy stable-since form, which is just a version.
        Stable(Option<VersionId>),
        /// The full `{stable, deprecated}` form.
        Full(AllowedVersions),
    }
    /// Struct combining the old and new representations of the allowed libfuncs map.
    #[derive(Deserialize)]
    #[serde(untagged)]
    enum FileRepr {
        Old(HashSet<SmolStr>),
        New(HashMap<SmolStr, EntryRepr>),
    }

    let versions = FileRepr::deserialize(deserializer)?;
    Ok(match versions {
        FileRepr::New(m) => m
            .into_iter()
            .map(|(id, entry)| {
                let versions = match entry {
                    EntryRepr::Stable(stable) => AllowedVersions { stable, deprecated: None },
                    EntryRepr::Full(versions) => versions,
                };
                (GenericLibfuncId::from_string(id), versions)
            })
            .collect(),
        FileRepr::Old(s) => s
            .into_iter()
            .map(|id| (GenericLibfuncId::from_string(id), AllowedVersions::default()))
            .collect(),
    })
}

/// The allowed libfuncs list to use if no list is supplied to the compiler.
/// Should only contain libfuncs that are audited and tested.
pub const BUILTIN_AUDITED_LIBFUNCS_LIST: &str = "audited";
/// The experimental list contains all the libfuncs and is currently used for development.
pub const BUILTIN_ALL_LIBFUNCS_LIST: &str = "all";

/// Returns the list of allowed Sierra libfuncs based on the provided list selector.
pub fn lookup_allowed_libfuncs_list(
    list_selector: ListSelector,
) -> Result<AllowedLibfuncs, AllowedLibfuncsError> {
    let list_name = list_selector.to_string();
    let allowed_libfuncs_str: String = match list_selector {
        ListSelector::ListName(list_name) => match list_name.as_str() {
            BUILTIN_ALL_LIBFUNCS_LIST => {
                include_str!("allowed_libfuncs_lists/all.json").to_string()
            }
            BUILTIN_AUDITED_LIBFUNCS_LIST => {
                include_str!("allowed_libfuncs_lists/audited.json").to_string()
            }
            _ => {
                return Err(AllowedLibfuncsError::UnexpectedAllowedLibfuncsList {
                    allowed_libfuncs_list_name: list_name,
                });
            }
        },
        ListSelector::ListFile(file_path) => fs::read_to_string(&file_path).map_err(|_| {
            AllowedLibfuncsError::UnknownAllowedLibfuncsFile {
                allowed_libfuncs_list_file: file_path,
            }
        })?,
        ListSelector::DefaultList => {
            include_str!("allowed_libfuncs_lists/audited.json").to_string()
        }
    };
    let allowed_libfuncs: Result<AllowedLibfuncs, serde_json::Error> =
        serde_json::from_str(&allowed_libfuncs_str);
    allowed_libfuncs.map_err(|_| AllowedLibfuncsError::DeserializationError {
        allowed_libfuncs_list_file: list_name,
    })
}
